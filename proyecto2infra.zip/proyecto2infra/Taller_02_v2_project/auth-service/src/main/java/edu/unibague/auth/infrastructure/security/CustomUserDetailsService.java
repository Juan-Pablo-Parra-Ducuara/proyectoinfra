package edu.unibague.auth.infrastructure.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import edu.unibague.auth.domain.model.Credential;
import edu.unibague.auth.application.port.out.CredentialRepositoryPort;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final CredentialRepositoryPort repository;

    public CustomUserDetailsService(CredentialRepositoryPort repository) {
        this.repository = repository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Credential credential = repository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));

        return User.withUsername(credential.getUsername())
                .password(credential.getPasswordHash())
                .roles(credential.getRole().name())
                .build();
    }
}
