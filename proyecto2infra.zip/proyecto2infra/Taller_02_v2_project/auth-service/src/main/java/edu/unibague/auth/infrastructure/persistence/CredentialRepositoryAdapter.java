package edu.unibague.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import edu.unibague.auth.application.port.out.CredentialRepositoryPort;
import edu.unibague.auth.domain.model.Credential;

@Repository
public class CredentialRepositoryAdapter implements CredentialRepositoryPort {

    private final CredentialJpaRepository repository;

    public CredentialRepositoryAdapter(CredentialJpaRepository repository) {
        this.repository = repository;
    }

    @Override
    public Optional<Credential> findByUsername(String username) {
        return repository.findByUsername(username).map(CredentialJpaEntity::toDomain);
    }

    @Override
    public boolean existsByUsername(String username) {
        return repository.existsByUsername(username);
    }

    @Override
    public boolean existsByEmail(String email) {
        return repository.existsByEmail(email);
    }

    @Override
    public Credential save(Credential credential) {
        return repository.save(CredentialJpaEntity.fromDomain(credential)).toDomain();
    }
}
