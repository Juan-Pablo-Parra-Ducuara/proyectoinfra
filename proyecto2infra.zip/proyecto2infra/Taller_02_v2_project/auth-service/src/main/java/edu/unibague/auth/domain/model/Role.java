package edu.unibague.auth.domain.model;

public enum Role {
    USER,
    ADMIN
}
