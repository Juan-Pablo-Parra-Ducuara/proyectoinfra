package edu.unibague.auth.infrastructure.persistence;

import java.time.Instant;
import java.util.UUID;

import edu.unibague.auth.domain.model.Credential;
import edu.unibague.auth.domain.model.Role;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "credentials")
public class CredentialJpaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, unique = true, length = 60)
    private String username;

    @Column(nullable = false, unique = true, length = 120)
    private String email;

    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role = Role.USER;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    static CredentialJpaEntity fromDomain(Credential credential) {
        CredentialJpaEntity entity = new CredentialJpaEntity();
        entity.id = credential.getId();
        entity.username = credential.getUsername();
        entity.email = credential.getEmail();
        entity.passwordHash = credential.getPasswordHash();
        entity.role = credential.getRole();
        entity.createdAt = credential.getCreatedAt();
        return entity;
    }

    Credential toDomain() {
        Credential credential = new Credential();
        credential.setId(id);
        credential.setUsername(username);
        credential.setEmail(email);
        credential.setPasswordHash(passwordHash);
        credential.setRole(role);
        credential.setCreatedAt(createdAt);
        return credential;
    }
}
