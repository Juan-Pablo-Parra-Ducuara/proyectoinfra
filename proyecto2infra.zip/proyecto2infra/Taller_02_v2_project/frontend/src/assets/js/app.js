(() => {
  'use strict';

  const SESSION_KEY = 'taller02.session.v1';
  const THEME_KEY = 'taller02.theme.v1';
  const THEMES = ['techno', 'classic'];
  const params = new URLSearchParams(window.location.search);
  const API_BASE = (params.get('api') ||
    (window.location.protocol === 'file:' ? 'http://localhost:8080' : '')).replace(/\/$/, '');

  const ICONS = {
    edit: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M14.5 5.5 18.5 9.5M4 20l1-4L16.6 4.4a2 2 0 0 1 2.8 0l.2.2a2 2 0 0 1 0 2.8L8 19l-4 1Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M6.5 7l.8 12a1 1 0 0 0 1 1h7.4a1 1 0 0 0 1-1l.8-12M10 11v5M14 11v5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    success: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><path d="m8 12.2 2.6 2.6L16 9.4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    error: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><path d="M12 7.5v5.2M12 16.4v.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><path d="M12 11v5.2M12 7.6v.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>'
  };

  const DEMO_USERS = {
    admin: { username: 'admin', password: 'Admin123!' },
    student: { username: 'student', password: 'Student123!' }
  };

  const dateFormatter = new Intl.DateTimeFormat('es-CO', { dateStyle: 'medium', timeStyle: 'short' });

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const els = {
    authView: $('#auth-view'),
    appView: $('#app-view'),
    loginForm: $('#login-form'),
    registerForm: $('#register-form'),
    loginUsername: $('#login-username'),
    loginPassword: $('#login-password'),
    registerUsername: $('#register-username'),
    registerEmail: $('#register-email'),
    registerPassword: $('#register-password'),
    toastStack: $('#toast-stack'),
    navAdmin: $('#nav-admin'),
    chipAvatar: $('#chip-avatar'),
    chipUsername: $('#chip-username'),
    chipRole: $('#chip-role'),
    logoutBtn: $('#logout-btn'),
    welcomeName: $('#welcome-name'),
    welcomeText: $('#welcome-text'),
    sessionMeta: $('#session-meta'),
    profilePanel: $('#profile-panel'),
    adminPanel: $('#admin-panel'),
    profileLoading: $('#profile-loading'),
    profileEmpty: $('#profile-empty'),
    profileCard: $('#profile-card'),
    createProfileForm: $('#create-profile-form'),
    createFirst: $('#create-first'),
    createLast: $('#create-last'),
    createPhone: $('#create-phone'),
    profileAvatar: $('#profile-avatar'),
    profileName: $('#profile-name'),
    profileUsername: $('#profile-username'),
    profileEmail: $('#profile-email'),
    profileRole: $('#profile-role'),
    detailName: $('#detail-name'),
    detailPhone: $('#detail-phone'),
    detailEmail: $('#detail-email'),
    detailUsername: $('#detail-username'),
    detailCreated: $('#detail-created'),
    detailUpdated: $('#detail-updated'),
    detailId: $('#detail-id'),
    editProfileBtn: $('#edit-profile-btn'),
    profileRefresh: $('#profile-refresh'),
    adminLoading: $('#admin-loading'),
    adminEmpty: $('#admin-empty'),
    adminTableWrap: $('#admin-table-wrap'),
    usersBody: $('#users-body'),
    userSearch: $('#user-search'),
    adminRefresh: $('#admin-refresh'),
    editDialog: $('#edit-dialog'),
    editForm: $('#edit-form'),
    editTitle: $('#edit-title'),
    editId: $('#edit-id'),
    editFirst: $('#edit-first'),
    editLast: $('#edit-last'),
    editPhone: $('#edit-phone'),
    editCancel: $('#edit-cancel'),
    confirmDialog: $('#confirm-dialog'),
    confirmText: $('#confirm-text'),
    confirmCancel: $('#confirm-cancel'),
    confirmAccept: $('#confirm-accept'),
    themeToggles: $$('[data-theme-toggle], #theme-toggle, #theme-toggle-auth'),
    themeLabels: $$('.theme-toggle__label')
  };

  const state = {
    session: null,
    profile: null,
    users: [],
    profileLoading: false,
    adminLoading: false,
    adminLoaded: false,
    editingId: null,
    pendingDelete: null
  };

  /* ------------------------------------------------------------ utilidades */

  function el(tag, className) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    return node;
  }

  function initialsOf(...parts) {
    const words = parts.filter(Boolean).join(' ').trim().split(/\s+/).filter(Boolean);
    if (!words.length) return '--';
    const first = words[0].charAt(0);
    const last = words.length > 1 ? words[words.length - 1].charAt(0) : '';
    return (first + last).toUpperCase();
  }

  function fullName(profile) {
    if (!profile) return '';
    return `${profile.firstName || ''} ${profile.lastName || ''}`.trim();
  }

  function fmtDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : dateFormatter.format(date);
  }

  function shortId(id) {
    return id ? String(id).slice(0, 8) : '—';
  }

  function toast(message, type = 'info') {
    const node = el('div', `toast toast--${type}`);
    const icon = el('span', 'toast__icon');
    icon.innerHTML = ICONS[type] || ICONS.info;
    const text = el('span', 'toast__text');
    text.textContent = message;
    node.append(icon, text);
    els.toastStack.appendChild(node);
    window.setTimeout(() => {
      node.classList.add('is-leaving');
      window.setTimeout(() => node.remove(), 220);
    }, 4200);
  }

  function setBusy(button, busy) {
    if (!button) return;
    button.disabled = busy;
    button.classList.toggle('is-busy', busy);
  }

  function setFormBusy(form, busy) {
    if (!form) return;
    setBusy(form.querySelector('button[type="submit"]'), busy);
  }

  function errorMessage(data, status) {
    if (data && typeof data === 'object') {
      if (data.validationErrors && typeof data.validationErrors === 'object') {
        const messages = Object.values(data.validationErrors).filter(Boolean);
        if (messages.length) return messages.join(' · ');
      }
      if (data.message) return data.message;
      if (data.error) return data.error;
    }
    if (typeof data === 'string' && data.trim()) return data.slice(0, 200);
    if (status === 401) return 'Credenciales inválidas o sesión expirada.';
    if (status === 403) return 'No tienes permisos para realizar esta acción.';
    if (status === 404) return 'El recurso solicitado no existe.';
    if (status === 409) return 'La operación entra en conflicto con datos existentes.';
    return `Ocurrió un error inesperado (HTTP ${status}).`;
  }

  /* --------------------------------------------------------------- sesión */

  function isExpired(session) {
    return Boolean(session && session.expiresAt && new Date(session.expiresAt).getTime() <= Date.now());
  }

  function loadTheme() {
    try {
      const stored = localStorage.getItem(THEME_KEY);
      return THEMES.includes(stored) ? stored : 'techno';
    } catch {
      return 'techno';
    }
  }

  function applyTheme(theme) {
    const next = THEMES.includes(theme) ? theme : 'techno';
    document.body.dataset.theme = next;
    els.themeLabels.forEach((label) => {
      label.textContent = next === 'techno' ? 'Tema tecno' : 'Tema clásico';
    });
    $$('[data-theme-toggle], #theme-toggle, #theme-toggle-auth').forEach((button) => {
      button.setAttribute('aria-pressed', String(next === 'techno'));
    });
    try {
      localStorage.setItem(THEME_KEY, next);
    } catch {
      /* almacenamiento no disponible */
    }
    return next;
  }

  function toggleTheme() {
    const current = document.body.dataset.theme === 'classic' ? 'classic' : 'techno';
    const next = current === 'techno' ? 'classic' : 'techno';
    applyTheme(next);
    toast(next === 'techno' ? 'Tema tecno rojo activado.' : 'Tema clásico activado.', 'info');
  }

  function loadSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || !parsed.accessToken) return null;
      if (isExpired(parsed)) {
        localStorage.removeItem(SESSION_KEY);
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  }

  function persistSession(session) {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    } catch {
      /* almacenamiento no disponible */
    }
  }

  function clearSession() {
    state.session = null;
    state.profile = null;
    state.users = [];
    state.adminLoaded = false;
    state.adminLoading = false;
    state.profileLoading = false;
    try {
      localStorage.removeItem(SESSION_KEY);
    } catch {
      /* almacenamiento no disponible */
    }
  }

  function handleExpired() {
    const hadSession = Boolean(state.session);
    clearSession();
    showAuth();
    setAuthMode('login');
    renderProfile();
    renderUsers();
    if (hadSession) toast('Tu sesión ha expirado. Inicia sesión de nuevo.', 'info');
  }

  /* ------------------------------------------------------------------ API */

  async function api(path, options = {}) {
    const { method = 'GET', body, auth = true } = options;

    if (auth && isExpired(state.session)) {
      handleExpired();
      const expired = new Error('La sesión ha expirado.');
      expired.status = 401;
      throw expired;
    }

    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (auth && state.session?.accessToken) {
      headers.Authorization = `Bearer ${state.session.accessToken}`;
    }

    let response;
    try {
      response = await fetch(`${API_BASE}${path}`, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body)
      });
    } catch {
      const networkError = new Error(
        'No se pudo conectar con el API Gateway. Verifica que los servicios estén en ejecución (docker compose up).'
      );
      networkError.status = 0;
      throw networkError;
    }

    const raw = await response.text();
    let data = null;
    if (raw) {
      try {
        data = JSON.parse(raw);
      } catch {
        data = raw;
      }
    }

    if (!response.ok) {
      if (response.status === 401 && auth) handleExpired();
      const failure = new Error(errorMessage(data, response.status));
      failure.status = response.status;
      failure.data = data;
      throw failure;
    }

    return data;
  }

  /* ------------------------------------------------------------- vistas */

  function showAuth() {
    els.authView.classList.remove('hidden');
    els.appView.classList.add('hidden');
  }

  function showApp() {
    els.authView.classList.add('hidden');
    els.appView.classList.remove('hidden');
  }

  function setAuthMode(mode) {
    $$('[data-auth-tab]').forEach((button) => {
      if (!button.classList.contains('tab')) return;
      const active = button.dataset.authTab === mode;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', String(active));
    });
    els.loginForm.classList.toggle('hidden', mode !== 'login');
    els.registerForm.classList.toggle('hidden', mode !== 'register');
  }

  function setSection(section) {
    $$('.nav__item').forEach((button) => {
      button.classList.toggle('is-active', button.dataset.nav === section);
    });
    els.profilePanel.classList.toggle('hidden', section !== 'profile');
    els.adminPanel.classList.toggle('hidden', section !== 'admin');

    if (section === 'admin') {
      if (!state.adminLoaded && !state.adminLoading) {
        loadUsers();
      } else {
        renderUsers();
      }
    }
  }

  function hydrateChrome() {
    const session = state.session;
    const name = fullName(state.profile) || session?.username || 'usuario';
    const role = session?.role || 'USER';

    els.chipUsername.textContent = session?.username || '—';
    els.chipAvatar.textContent = initialsOf(name);
    els.chipRole.textContent = role;
    els.chipRole.classList.toggle('role-pill--admin', role === 'ADMIN');
    els.welcomeName.textContent = name;
    els.navAdmin.classList.toggle('hidden', role !== 'ADMIN');
    els.sessionMeta.textContent = session?.expiresAt
      ? `Sesión activa hasta ${fmtDate(session.expiresAt)}`
      : 'Conectado al API Gateway';

    if (state.profile) {
      els.welcomeText.textContent = 'Gestiona tu información personal y consulta tu perfil.';
    } else {
      els.welcomeText.textContent = 'Crea tu perfil para comenzar a usar el servicio de usuarios.';
    }
  }

  /* -------------------------------------------------------------- perfil */

  function renderProfile() {
    const loading = state.profileLoading;
    const profile = state.profile;

    els.profileLoading.classList.toggle('hidden', !loading);
    els.profileEmpty.classList.toggle('hidden', loading || Boolean(profile));
    els.profileCard.classList.toggle('hidden', loading || !profile);

    if (loading || !profile) return;

    const name = fullName(profile) || profile.username || '—';
    const role = state.session?.role || 'USER';

    els.profileAvatar.textContent = initialsOf(name);
    els.profileName.textContent = name;
    els.profileUsername.textContent = `@${profile.username || '—'}`;
    els.profileEmail.textContent = profile.email || '—';
    els.profileRole.textContent = role;
    els.profileRole.classList.toggle('role-pill--admin', role === 'ADMIN');

    els.detailName.textContent = name;
    els.detailPhone.textContent = profile.phone || 'Sin registrar';
    els.detailEmail.textContent = profile.email || '—';
    els.detailUsername.textContent = profile.username || '—';
    els.detailCreated.textContent = fmtDate(profile.createdAt);
    els.detailUpdated.textContent = fmtDate(profile.updatedAt);
    els.detailId.textContent = profile.id || '—';
  }

  async function loadProfile() {
    if (!state.session) return;

    state.profileLoading = true;
    renderProfile();

    try {
      state.profile = await api('/api/users/me');
      state.adminLoaded = false;
    } catch (error) {
      if (error.status === 404) {
        state.profile = null;
      } else if (error.status !== 401) {
        state.profile = null;
        toast(error.message, 'error');
      }
    } finally {
      state.profileLoading = false;
      renderProfile();
      hydrateChrome();
    }
  }

  /* ------------------------------------------------------------ usuarios */

  function buildUserRow(user) {
    const row = document.createElement('tr');
    const name = fullName(user) || user.username || '—';

    const userCell = document.createElement('td');
    const userWrap = el('div', 'cell-user');
    const avatar = el('span', 'avatar');
    avatar.textContent = initialsOf(name);
    const textWrap = el('div', 'cell-user__text');
    const username = document.createElement('strong');
    username.textContent = `@${user.username || '—'}`;
    if (user.id === state.session?.userId) {
      const tag = el('span', 'self-tag');
      tag.textContent = 'Tú';
      username.appendChild(tag);
    }
    const idLine = document.createElement('span');
    idLine.textContent = shortId(user.id);
    textWrap.append(username, idLine);
    userWrap.append(avatar, textWrap);
    userCell.appendChild(userWrap);

    const nameCell = el('td', 'cell-name');
    nameCell.textContent = name;

    const emailCell = el('td', 'cell-muted');
    emailCell.textContent = user.email || '—';

    const phoneCell = el('td', 'cell-muted');
    phoneCell.textContent = user.phone || '—';

    const createdCell = el('td', 'cell-muted');
    createdCell.textContent = fmtDate(user.createdAt);

    const actionsCell = el('td', 'table__actions');
    const actions = el('div', 'row-actions');

    const editButton = el('button', 'icon-btn');
    editButton.type = 'button';
    editButton.title = 'Editar perfil';
    editButton.setAttribute('aria-label', `Editar perfil de ${user.username}`);
    editButton.dataset.action = 'edit';
    editButton.dataset.id = user.id;
    editButton.innerHTML = ICONS.edit;

    const deleteButton = el('button', 'icon-btn icon-btn--danger');
    deleteButton.type = 'button';
    deleteButton.title = 'Eliminar perfil';
    deleteButton.setAttribute('aria-label', `Eliminar perfil de ${user.username}`);
    deleteButton.dataset.action = 'delete';
    deleteButton.dataset.id = user.id;
    deleteButton.innerHTML = ICONS.trash;

    actions.append(editButton, deleteButton);
    actionsCell.appendChild(actions);

    row.append(userCell, nameCell, emailCell, phoneCell, createdCell, actionsCell);
    return row;
  }

  function renderUsers() {
    if (state.adminLoading) {
      els.adminLoading.classList.remove('hidden');
      els.adminTableWrap.classList.add('hidden');
      els.adminEmpty.classList.add('hidden');
      return;
    }

    els.adminLoading.classList.add('hidden');

    const query = (els.userSearch.value || '').trim().toLowerCase();
    const users = state.users.filter((user) => {
      if (!query) return true;
      return [user.firstName, user.lastName, user.username, user.email, user.phone]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .includes(query);
    });

    els.usersBody.replaceChildren();

    if (!users.length) {
      els.adminTableWrap.classList.add('hidden');
      els.adminEmpty.classList.remove('hidden');
      const title = els.adminEmpty.querySelector('h4');
      const text = els.adminEmpty.querySelector('p');
      if (state.users.length === 0) {
        title.textContent = 'Todavía no hay perfiles';
        text.textContent = 'Los perfiles aparecerán aquí cuando los usuarios los creen.';
      } else {
        title.textContent = 'Sin resultados';
        text.textContent = 'No hay perfiles que coincidan con la búsqueda.';
      }
      return;
    }

    els.adminEmpty.classList.add('hidden');
    els.adminTableWrap.classList.remove('hidden');

    const fragment = document.createDocumentFragment();
    users.forEach((user) => fragment.appendChild(buildUserRow(user)));
    els.usersBody.appendChild(fragment);
  }

  async function loadUsers() {
    state.adminLoading = true;
    renderUsers();

    try {
      state.users = await api('/api/users');
      state.adminLoaded = true;
    } catch (error) {
      state.users = [];
      state.adminLoaded = false;
      if (error.status !== 401) toast(error.message, 'error');
    } finally {
      state.adminLoading = false;
      renderUsers();
    }
  }

  /* ------------------------------------------------------------- diálogos */

  function openEdit(profile) {
    if (!profile) return;
    state.editingId = profile.id;
    const isSelf = profile.id === state.session?.userId;

    els.editTitle.textContent = isSelf ? 'Editar mi perfil' : `Editar perfil de @${profile.username}`;
    els.editId.value = profile.id;
    els.editFirst.value = profile.firstName || '';
    els.editLast.value = profile.lastName || '';
    els.editPhone.value = profile.phone || '';
    els.editDialog.showModal();
  }

  function askDelete(profile) {
    if (!profile) return;
    state.pendingDelete = profile;
    const name = fullName(profile) || `@${profile.username}`;
    els.confirmText.textContent =
      `Se eliminará el perfil de ${name} (@${profile.username}). Esta acción no se puede deshacer.`;
    els.confirmDialog.showModal();
  }

  /* --------------------------------------------------------------- flujos */

  async function handleLogin(event) {
    event.preventDefault();
    if (!els.loginForm.reportValidity()) return;

    setFormBusy(els.loginForm, true);
    try {
      const auth = await api('/api/auth/login', {
        method: 'POST',
        auth: false,
        body: {
          username: els.loginUsername.value.trim(),
          password: els.loginPassword.value
        }
      });

      state.session = {
        tokenType: auth.tokenType,
        accessToken: auth.accessToken,
        expiresAt: auth.expiresAt,
        userId: auth.userId,
        username: auth.username,
        role: auth.role
      };
      persistSession(state.session);

      state.profile = null;
      state.users = [];
      state.adminLoaded = false;
      els.loginForm.reset();

      showApp();
      setSection('profile');
      hydrateChrome();
      toast(`Bienvenido, ${state.session.username}.`, 'success');
      await loadProfile();
    } catch (error) {
      if (error.status !== 401) toast(error.message, 'error');
      else toast('Usuario o contraseña incorrectos.', 'error');
    } finally {
      setFormBusy(els.loginForm, false);
    }
  }

  async function handleRegister(event) {
    event.preventDefault();
    if (!els.registerForm.reportValidity()) return;

    setFormBusy(els.registerForm, true);
    try {
      const username = els.registerUsername.value.trim();
      await api('/api/auth/register', {
        method: 'POST',
        auth: false,
        body: {
          username,
          email: els.registerEmail.value.trim(),
          password: els.registerPassword.value
        }
      });

      els.registerForm.reset();
      setAuthMode('login');
      els.loginUsername.value = username;
      els.loginPassword.focus();
      toast('Cuenta creada. Ahora inicia sesión con tu contraseña.', 'success');
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      setFormBusy(els.registerForm, false);
    }
  }

  async function handleCreateProfile(event) {
    event.preventDefault();
    if (!els.createProfileForm.reportValidity()) return;

    setFormBusy(els.createProfileForm, true);
    try {
      const created = await api('/api/users', {
        method: 'POST',
        body: {
          firstName: els.createFirst.value.trim(),
          lastName: els.createLast.value.trim(),
          phone: els.createPhone.value.trim()
        }
      });

      state.profile = created;
      state.adminLoaded = false;
      els.createProfileForm.reset();
      renderProfile();
      hydrateChrome();
      toast('Perfil creado correctamente.', 'success');
    } catch (error) {
      if (error.status !== 401) toast(error.message, 'error');
    } finally {
      setFormBusy(els.createProfileForm, false);
    }
  }

  async function handleEditProfile(event) {
    event.preventDefault();
    if (!els.editForm.reportValidity()) return;

    const id = els.editId.value;
    if (!id) return;

    const submitButton = els.editForm.querySelector('button[type="submit"]');
    setBusy(submitButton, true);

    try {
      const updated = await api(`/api/users/${encodeURIComponent(id)}`, {
        method: 'PUT',
        body: {
          firstName: els.editFirst.value.trim(),
          lastName: els.editLast.value.trim(),
          phone: els.editPhone.value.trim()
        }
      });

      if (state.profile?.id === id) state.profile = updated;
      const index = state.users.findIndex((user) => user.id === id);
      if (index >= 0) state.users[index] = updated;

      els.editDialog.close();
      renderProfile();
      hydrateChrome();
      renderUsers();
      toast('Perfil actualizado.', 'success');
    } catch (error) {
      if (error.status !== 401) toast(error.message, 'error');
    } finally {
      setBusy(submitButton, false);
    }
  }

  async function handleDeleteProfile() {
    const profile = state.pendingDelete;
    if (!profile) return;

    setBusy(els.confirmAccept, true);
    try {
      await api(`/api/users/${encodeURIComponent(profile.id)}`, { method: 'DELETE' });

      state.users = state.users.filter((user) => user.id !== profile.id);
      if (state.profile?.id === profile.id) {
        state.profile = null;
        state.adminLoaded = false;
        renderProfile();
        hydrateChrome();
      }

      state.pendingDelete = null;
      els.confirmDialog.close();
      renderUsers();
      toast('Perfil eliminado.', 'success');
    } catch (error) {
      if (error.status !== 401) toast(error.message, 'error');
    } finally {
      setBusy(els.confirmAccept, false);
    }
  }

  function handleLogout() {
    clearSession();
    els.loginForm.reset();
    showAuth();
    setAuthMode('login');
    renderProfile();
    renderUsers();
    els.loginUsername.focus();
    toast('Sesión cerrada.', 'info');
  }

  /* --------------------------------------------------------------- eventos */

  function bindEvents() {
    $$('[data-auth-tab]').forEach((button) => {
      button.addEventListener('click', () => setAuthMode(button.dataset.authTab));
    });

    $$('[data-demo]').forEach((button) => {
      button.addEventListener('click', () => {
        const demo = DEMO_USERS[button.dataset.demo];
        if (!demo) return;
        setAuthMode('login');
        els.loginUsername.value = demo.username;
        els.loginPassword.value = demo.password;
        els.loginPassword.focus();
      });
    });

    els.themeToggles.forEach((button) => {
      button.addEventListener('click', toggleTheme);
    });

    $$('.nav__item').forEach((button) => {
      button.addEventListener('click', () => setSection(button.dataset.nav));
    });

    els.loginForm.addEventListener('submit', handleLogin);
    els.registerForm.addEventListener('submit', handleRegister);
    els.createProfileForm.addEventListener('submit', handleCreateProfile);
    els.editForm.addEventListener('submit', handleEditProfile);

    els.logoutBtn.addEventListener('click', handleLogout);
    els.profileRefresh.addEventListener('click', () => loadProfile());
    els.adminRefresh.addEventListener('click', () => loadUsers());
    els.editProfileBtn.addEventListener('click', () => openEdit(state.profile));

    els.userSearch.addEventListener('input', renderUsers);

    els.usersBody.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-action]');
      if (!button) return;
      const user = state.users.find((item) => item.id === button.dataset.id);
      if (!user) return;
      if (button.dataset.action === 'edit') openEdit(user);
      else if (button.dataset.action === 'delete') askDelete(user);
    });

    els.editCancel.addEventListener('click', () => els.editDialog.close());
    els.confirmCancel.addEventListener('click', () => {
      state.pendingDelete = null;
      els.confirmDialog.close();
    });
    els.confirmAccept.addEventListener('click', handleDeleteProfile);

    [els.editDialog, els.confirmDialog].forEach((dialog) => {
      dialog.addEventListener('click', (event) => {
        if (event.target === dialog) dialog.close();
      });
    });

    els.confirmDialog.addEventListener('close', () => {
      state.pendingDelete = null;
    });
  }

  /* ----------------------------------------------------------------- inicio */

  function init() {
    applyTheme(loadTheme());
    bindEvents();
    state.session = loadSession();

    if (state.session) {
      showApp();
      setSection('profile');
      hydrateChrome();
      loadProfile();
    } else {
      showAuth();
      setAuthMode('login');
    }
  }

  init();
})();
