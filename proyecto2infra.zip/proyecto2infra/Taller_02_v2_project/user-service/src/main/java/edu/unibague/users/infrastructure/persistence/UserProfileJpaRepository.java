package edu.unibague.users.infrastructure.persistence;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserProfileJpaRepository extends JpaRepository<UserProfileJpaEntity, UUID> {

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);
}
