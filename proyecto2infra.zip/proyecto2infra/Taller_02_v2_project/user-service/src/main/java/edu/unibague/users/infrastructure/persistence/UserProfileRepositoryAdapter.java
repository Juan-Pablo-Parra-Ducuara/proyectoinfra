package edu.unibague.users.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Repository;

import edu.unibague.users.application.port.out.UserProfileRepositoryPort;
import edu.unibague.users.domain.model.UserProfile;

@Repository
public class UserProfileRepositoryAdapter implements UserProfileRepositoryPort {

    private final UserProfileJpaRepository repository;

    public UserProfileRepositoryAdapter(UserProfileJpaRepository repository) {
        this.repository = repository;
    }

    @Override
    public boolean existsById(UUID id) {
        return repository.existsById(id);
    }

    @Override
    public boolean existsByUsername(String username) {
        return repository.existsByUsername(username);
    }

    @Override
    public boolean existsByEmail(String email) {
        return repository.existsByEmail(email);
    }

    @Override
    public UserProfile save(UserProfile profile) {
        return repository.save(UserProfileJpaEntity.fromDomain(profile)).toDomain();
    }

    @Override
    public List<UserProfile> findAll() {
        return repository.findAll().stream().map(UserProfileJpaEntity::toDomain).toList();
    }

    @Override
    public Optional<UserProfile> findById(UUID id) {
        return repository.findById(id).map(UserProfileJpaEntity::toDomain);
    }

    @Override
    public void delete(UserProfile profile) {
        repository.deleteById(profile.getId());
    }
}
