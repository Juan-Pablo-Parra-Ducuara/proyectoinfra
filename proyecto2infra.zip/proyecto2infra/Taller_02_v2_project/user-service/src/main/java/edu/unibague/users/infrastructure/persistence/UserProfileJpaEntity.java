package edu.unibague.users.infrastructure.persistence;

import java.time.Instant;
import java.util.UUID;

import edu.unibague.users.domain.model.UserProfile;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_profiles")
public class UserProfileJpaEntity {

    @Id
    private UUID id;

    @Column(nullable = false, unique = true, length = 60)
    private String username;

    @Column(nullable = false, unique = true, length = 120)
    private String email;

    @Column(name = "first_name", nullable = false, length = 80)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 80)
    private String lastName;

    @Column(length = 30)
    private String phone;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt = Instant.now();

    static UserProfileJpaEntity fromDomain(UserProfile profile) {
        UserProfileJpaEntity entity = new UserProfileJpaEntity();
        entity.id = profile.getId();
        entity.username = profile.getUsername();
        entity.email = profile.getEmail();
        entity.firstName = profile.getFirstName();
        entity.lastName = profile.getLastName();
        entity.phone = profile.getPhone();
        entity.createdAt = profile.getCreatedAt();
        entity.updatedAt = profile.getUpdatedAt();
        return entity;
    }

    UserProfile toDomain() {
        UserProfile profile = new UserProfile();
        profile.setId(id);
        profile.setUsername(username);
        profile.setEmail(email);
        profile.setFirstName(firstName);
        profile.setLastName(lastName);
        profile.setPhone(phone);
        profile.setCreatedAt(createdAt);
        profile.setUpdatedAt(updatedAt);
        return profile;
    }
}
