# Entrega — Taller 02 v2.0

Aplicación Distribuida con Arquitectura de Microservicios — Universidad de Ibagué (Web, APIs y Microservicios).

## Estructura

```
entrega/
├── README.md                      ← este índice
├── proyecto/                      ← código fuente completo del taller
│   ├── pom.xml                    (multi-módulo: api-gateway, auth-service, user-service)
│   ├── docker-compose.yml         (6 servicios: 2 PostgreSQL + 3 Java + frontend nginx)
│   ├── .env.example               (copiar a .env antes de levantar)
│   ├── .github/workflows/ci-cd.yml
│   ├── api-gateway/  auth-service/  user-service/
│   ├── frontend/src/              (HTML/CSS/JS; servido con nginx)
│   ├── postman/                   (colección + ambiente)
│   └── scripts/generate-rsa-keys.sh
└── evidencias/
    ├── Taller_02_Evidencias.docx  ← informe con resultados verificados y lugares para capturas
    └── capturas/                  ← carpetas donde guardar las capturas de pantalla
        ├── 01_entorno/            versiones de Docker, docker info
        ├── 02_docker/             compose up, compose ps, volume ls
        ├── 03_flyway/             logs de Flyway, \dt en ambas BD
        ├── 04_health_swagger/     health UP, Swagger 8081/8082, X-Correlation-Id
        ├── 05_pruebas_funcionales/ login, CRUD, 401/403/409/400
        ├── 06_postman/            colección ejecutada
        ├── 07_persistencia/       down/up y datos intactos
        └── 08_cicd/               GitHub Actions
```

## Cómo ejecutar el proyecto

```bash
cd proyecto
cp .env.example .env
docker compose up --build -d
```

- Frontend web: http://localhost:3000
- Gateway: http://localhost:8080
- Auth Swagger: http://localhost:8081/swagger-ui.html
- Users Swagger: http://localhost:8082/swagger-ui.html

Usuarios demo: `admin` / `Admin123!` (ADMIN) y `student` / `Student123!` (USER).

## Qué queda pendiente para el estudiante

1. **Capturas**: abrir `evidencias/Taller_02_Evidencias.docx`, ejecutar los comandos del informe y pegar las capturas en las carpetas de `evidencias/capturas/` (Figuras 1–25 del documento).
2. **CI/CD**: crear un repositorio en GitHub, hacer push de la carpeta `proyecto/` y verificar en la pestaña Actions que el workflow `ci-cd` queda en verde; capturar esa pantalla en `08_cicd/`.
3. Completar en el documento los datos de portada (nombre, código, fecha).
